using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using KP_Kursovaya_Nazarenko.Models;

namespace KP_Kursovaya_Nazarenko.Controls
{
    public class ParkingMapControl : Control
    {
        private readonly List<SpotVisual> _visuals = new List<SpotVisual>();
        private ParkingLot _lot;
        private string _filter = "Все";
        private string _search = string.Empty;
        private string _hoverCode;
        private string _selectedCode;

        public event EventHandler SelectionChanged;

        public ParkingSpot SelectedSpot
        {
            get { return _lot == null ? null : _lot.FindByCode(_selectedCode); }
        }

        public ParkingMapControl()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.UserPaint, true);
            BackColor = Theme.Background;
            Font = Theme.Body;
            Cursor = Cursors.Hand;
        }

        public void Bind(ParkingLot lot, string filter, string search, string selectedCode)
        {
            _lot = lot;
            _filter = filter ?? "Все";
            _search = (search ?? string.Empty).Trim();
            if (!string.IsNullOrEmpty(selectedCode))
                _selectedCode = selectedCode;
            RebuildLayout();
            Invalidate();
        }

        public void SelectSpot(string code)
        {
            _selectedCode = code;
            Invalidate();
            if (SelectionChanged != null)
                SelectionChanged(this, EventArgs.Empty);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            var hit = HitTest(e.Location);
            var code = hit == null ? null : hit.Spot.Code;
            if (_hoverCode == code) return;
            _hoverCode = code;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _hoverCode = null;
            Invalidate();
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            var hit = HitTest(e.Location);
            if (hit == null) return;
            SelectSpot(hit.Spot.Code);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Theme.Background);

            if (_lot == null) return;

            using (var titleBrush = new SolidBrush(Theme.Text))
            using (var mutedBrush = new SolidBrush(Theme.Muted))
            {
                foreach (var group in _visuals.GroupBy(v => v.Spot.Zone))
                {
                    var first = group.First();
                    g.DrawString("Зона " + group.Key, Theme.Heading, titleBrush, first.Bounds.X, first.Bounds.Y - 28);
                    g.DrawString(group.Count(v => v.Spot.IsFree) + " свободно", Theme.Small, mutedBrush, first.Bounds.X + 78, first.Bounds.Y - 25);
                }
            }

            foreach (var visual in _visuals)
                DrawSpot(g, visual);
        }

        private void DrawSpot(Graphics g, SpotVisual visual)
        {
            var spot = visual.Spot;
            var bounds = visual.Bounds;
            var hovered = spot.Code == _hoverCode;
            var selected = spot.Code == _selectedCode;
            var matchesSearch = MatchesSearch(spot);
            var filteredOut = !MatchesFilter(spot);

            Color fill;
            Color accent;
            if (spot.Type == SpotType.Disabled && spot.IsFree)
            {
                fill = Theme.DisabledSoft;
                accent = Theme.Disabled;
            }
            else if (spot.IsFree)
            {
                fill = Theme.FreeSoft;
                accent = Theme.Free;
            }
            else
            {
                fill = Theme.OccupiedSoft;
                accent = Theme.Occupied;
            }

            if (filteredOut)
            {
                fill = Color.FromArgb(236, 238, 241);
                accent = Theme.Line;
            }

            var drawBounds = hovered ? Rectangle.Inflate(bounds, 2, 2) : bounds;
            Theme.DrawRoundedFill(g, drawBounds, 10, fill);

            if (selected)
                Theme.DrawRoundedBorder(g, drawBounds, 10, Theme.Header, 2f);
            else if (matchesSearch && !string.IsNullOrEmpty(_search))
                Theme.DrawRoundedBorder(g, drawBounds, 10, Theme.Accent, 2f);
            else
                Theme.DrawRoundedBorder(g, drawBounds, 10, Color.FromArgb(40, accent), 1f);

            using (var accentBrush = new SolidBrush(accent))
            {
                g.FillRectangle(accentBrush, new Rectangle(drawBounds.X, drawBounds.Y, drawBounds.Width, 4));
            }

            var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            using (var textBrush = new SolidBrush(filteredOut ? Theme.Muted : Theme.Text))
            {
                g.DrawString(spot.Code, Theme.Heading, textBrush,
                    new RectangleF(drawBounds.X, drawBounds.Y + 10, drawBounds.Width, 22), format);
            }

            using (var muted = new SolidBrush(filteredOut ? Color.FromArgb(180, Theme.Muted) : Theme.Muted))
            {
                var second = spot.IsFree
                    ? spot.TypeLabel
                    : (string.IsNullOrEmpty(spot.Plate) ? "Занято" : spot.Plate);
                g.DrawString(second, Theme.Small, muted,
                    new RectangleF(drawBounds.X + 4, drawBounds.Y + 34, drawBounds.Width - 8, 28), format);
            }
        }

        private void RebuildLayout()
        {
            _visuals.Clear();
            if (_lot == null) return;

            const int spotWidth = 78;
            const int spotHeight = 70;
            const int gap = 10;
            const int left = 24;
            int y = 44;

            foreach (var zone in _lot.Zones)
            {
                var zoneSpots = _lot.Spots.Where(s => s.Zone == zone)
                    .OrderBy(s => s.Row).ThenBy(s => s.Column).ToList();
                int rows = zoneSpots.Max(s => s.Row) + 1;

                for (int row = 0; row < rows; row++)
                {
                    var rowSpots = zoneSpots.Where(s => s.Row == row).OrderBy(s => s.Column);
                    int x = left;
                    foreach (var spot in rowSpots)
                    {
                        _visuals.Add(new SpotVisual
                        {
                            Spot = spot,
                            Bounds = new Rectangle(x, y, spotWidth, spotHeight)
                        });
                        x += spotWidth + gap;
                    }
                    y += spotHeight + 12;
                }

                y += 28;
            }

            Height = Math.Max(Parent == null ? 420 : Parent.ClientSize.Height, y + 20);
        }

        private SpotVisual HitTest(Point point)
        {
            return _visuals.FirstOrDefault(v => v.Bounds.Contains(point));
        }

        private bool MatchesFilter(ParkingSpot spot)
        {
            switch (_filter)
            {
                case "Свободные": return spot.IsFree;
                case "Занятые": return !spot.IsFree;
                case "Для инвалидов": return spot.Type == SpotType.Disabled;
                default: return true;
            }
        }

        private bool MatchesSearch(ParkingSpot spot)
        {
            if (string.IsNullOrEmpty(_search)) return false;
            return (!string.IsNullOrEmpty(spot.Plate) &&
                    spot.Plate.IndexOf(_search, StringComparison.OrdinalIgnoreCase) >= 0) ||
                   spot.Code.IndexOf(_search, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private class SpotVisual
        {
            public ParkingSpot Spot;
            public Rectangle Bounds;
        }
    }
}
