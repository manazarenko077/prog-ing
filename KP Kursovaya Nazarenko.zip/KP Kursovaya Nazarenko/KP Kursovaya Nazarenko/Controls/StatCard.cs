using System;
using System.Drawing;
using System.Windows.Forms;

namespace KP_Kursovaya_Nazarenko.Controls
{
    public class StatCard : Panel
    {
        private readonly Label _valueLabel;
        private readonly Label _titleLabel;
        private readonly Panel _accent;

        public StatCard(string title, Color accent)
        {
            Height = 78;
            BackColor = Theme.Surface;
            Padding = new Padding(14, 12, 14, 12);

            _accent = new Panel
            {
                Dock = DockStyle.Left,
                Width = 4,
                BackColor = accent
            };

            _titleLabel = new Label
            {
                Text = title,
                Dock = DockStyle.Top,
                Height = 20,
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Padding = new Padding(10, 0, 0, 0)
            };

            _valueLabel = new Label
            {
                Text = "0",
                Dock = DockStyle.Fill,
                Font = Theme.Title,
                ForeColor = Theme.Text,
                Padding = new Padding(10, 0, 0, 0),
                TextAlign = ContentAlignment.MiddleLeft
            };

            Controls.Add(_valueLabel);
            Controls.Add(_titleLabel);
            Controls.Add(_accent);
        }

        public void SetValue(string value)
        {
            _valueLabel.Text = value;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Theme.DrawRoundedBorder(e.Graphics, new Rectangle(0, 0, Width - 1, Height - 1), 8, Theme.Line);
        }
    }
}
