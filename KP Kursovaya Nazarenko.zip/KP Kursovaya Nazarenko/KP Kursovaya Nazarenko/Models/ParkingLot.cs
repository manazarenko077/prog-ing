using System;
using System.Collections.Generic;
using System.Linq;

namespace KP_Kursovaya_Nazarenko.Models
{
    public class ParkingLot
    {
        public string Name { get; set; }
        public List<ParkingSpot> Spots { get; set; }
        public List<ParkingEvent> Events { get; set; }

        public ParkingLot()
        {
            Name = "Городская стоянка";
            Spots = new List<ParkingSpot>();
            Events = new List<ParkingEvent>();
        }

        [System.Xml.Serialization.XmlIgnore]
        public int TotalCount { get { return Spots.Count; } }

        [System.Xml.Serialization.XmlIgnore]
        public int FreeCount { get { return Spots.Count(s => s.IsFree); } }

        [System.Xml.Serialization.XmlIgnore]
        public int OccupiedCount { get { return Spots.Count(s => !s.IsFree); } }

        [System.Xml.Serialization.XmlIgnore]
        public int OccupancyPercent
        {
            get
            {
                if (TotalCount == 0) return 0;
                return (int)Math.Round(OccupiedCount * 100.0 / TotalCount);
            }
        }

        [System.Xml.Serialization.XmlIgnore]
        public IEnumerable<string> Zones
        {
            get { return Spots.Select(s => s.Zone).Distinct().OrderBy(z => z); }
        }

        public ParkingSpot FindByCode(string code)
        {
            return Spots.FirstOrDefault(s =>
                string.Equals(s.Code, code, StringComparison.OrdinalIgnoreCase));
        }

        public ParkingSpot FindByPlate(string plate)
        {
            if (string.IsNullOrWhiteSpace(plate)) return null;
            var normalized = plate.Trim().ToUpperInvariant();
            return Spots.FirstOrDefault(s =>
                !s.IsFree && string.Equals(s.Plate, normalized, StringComparison.OrdinalIgnoreCase));
        }

        public ParkingSpot FindFirstFree(SpotType? type = null, string zone = null)
        {
            return Spots
                .Where(s => s.IsFree)
                .Where(s => type == null || s.Type == type.Value)
                .Where(s => string.IsNullOrEmpty(zone) || s.Zone == zone)
                .OrderBy(s => s.Zone)
                .ThenBy(s => s.Row)
                .ThenBy(s => s.Column)
                .FirstOrDefault();
        }

        public bool Occupy(ParkingSpot spot, string plate, string driverName, out string error)
        {
            error = null;
            if (spot == null)
            {
                error = "Место не выбрано.";
                return false;
            }
            if (!spot.IsFree)
            {
                error = "Место уже занято.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(plate))
            {
                error = "Укажите номер автомобиля.";
                return false;
            }

            var existing = FindByPlate(plate);
            if (existing != null)
            {
                error = "Автомобиль уже стоит на месте " + existing.Code + ".";
                return false;
            }

            spot.Occupy(plate, driverName);
            AddEvent("Въезд", spot.Code, spot.Plate, "Место занято");
            return true;
        }

        public bool Release(ParkingSpot spot, out string error)
        {
            error = null;
            if (spot == null)
            {
                error = "Место не выбрано.";
                return false;
            }
            if (spot.IsFree)
            {
                error = "Место уже свободно.";
                return false;
            }

            var plate = spot.Plate;
            spot.Release();
            AddEvent("Выезд", spot.Code, plate, "Место освобождено");
            return true;
        }

        public void AddEvent(string action, string spotCode, string plate, string details)
        {
            Events.Insert(0, new ParkingEvent
            {
                Time = DateTime.Now,
                Action = action,
                SpotCode = spotCode,
                Plate = plate,
                Details = details
            });

            if (Events.Count > 80)
                Events.RemoveRange(80, Events.Count - 80);
        }

        public static ParkingLot CreateDemo()
        {
            var lot = new ParkingLot { Name = "Городская стоянка" };
            var zones = new[] { "A", "B", "C" };

            foreach (var zone in zones)
            {
                for (int row = 0; row < 2; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        var type = SpotType.Standard;
                        if (zone == "A" && row == 0 && col < 2)
                            type = SpotType.Disabled;
                        else if (zone == "C" && col >= 6)
                            type = SpotType.Compact;

                        lot.Spots.Add(new ParkingSpot
                        {
                            Zone = zone,
                            Row = row,
                            Column = col,
                            Code = zone + "-" + (row * 8 + col + 1).ToString("00"),
                            Type = type,
                            Status = SpotStatus.Free
                        });
                    }
                }
            }

            OccupyQuiet(lot, "A-05", "А123ВС77", "Иванов П.С.");
            OccupyQuiet(lot, "A-08", "О777ОО177", "Петрова М.А.");
            OccupyQuiet(lot, "B-03", "К045МН99", "Сидоров А.В.");
            OccupyQuiet(lot, "B-12", "Е901ТТ777", "Кузнецов Д.И.");
            OccupyQuiet(lot, "C-02", "У318КК50", "Морозова Е.Н.");
            OccupyQuiet(lot, "C-07", "М256ОР197", "Волков И.К.");

            lot.AddEvent("Система", null, null, "Парковка открыта");
            return lot;
        }

        private static void OccupyQuiet(ParkingLot lot, string code, string plate, string driver)
        {
            var spot = lot.FindByCode(code);
            if (spot == null) return;
            spot.Occupy(plate, driver);
            spot.OccupiedAt = DateTime.Now.AddMinutes(-new Random(code.GetHashCode()).Next(8, 140));
        }
    }
}
