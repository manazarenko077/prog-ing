namespace KP_Kursovaya_Nazarenko.Models
{
    public enum SpotStatus
    {
        Free,
        Occupied
    }

    public enum SpotType
    {
        Standard,
        Compact,
        Disabled
    }
}
