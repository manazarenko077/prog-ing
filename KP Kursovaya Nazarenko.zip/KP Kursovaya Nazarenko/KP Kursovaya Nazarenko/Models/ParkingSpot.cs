using System;
using System.Xml.Serialization;

namespace KP_Kursovaya_Nazarenko.Models
{
    public class ParkingSpot
    {
        public string Code { get; set; }
        public string Zone { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
        public SpotType Type { get; set; }
        public SpotStatus Status { get; set; }
        public string Plate { get; set; }
        public string DriverName { get; set; }

        [XmlIgnore]
        public DateTime? OccupiedAt { get; set; }

        public string OccupiedAtValue
        {
            get { return OccupiedAt.HasValue ? OccupiedAt.Value.ToString("o") : null; }
            set
            {
                DateTime parsed;
                OccupiedAt = DateTime.TryParse(value, out parsed) ? parsed : (DateTime?)null;
            }
        }

        [XmlIgnore]
        public bool IsFree
        {
            get { return Status == SpotStatus.Free; }
        }

        [XmlIgnore]
        public string TypeLabel
        {
            get
            {
                switch (Type)
                {
                    case SpotType.Compact: return "Компакт";
                    case SpotType.Disabled: return "Для инвалидов";
                    default: return "Стандарт";
                }
            }
        }

        [XmlIgnore]
        public TimeSpan? OccupiedDuration
        {
            get
            {
                if (!OccupiedAt.HasValue) return null;
                return DateTime.Now - OccupiedAt.Value;
            }
        }

        public void Occupy(string plate, string driverName)
        {
            Status = SpotStatus.Occupied;
            Plate = (plate ?? string.Empty).Trim().ToUpperInvariant();
            DriverName = (driverName ?? string.Empty).Trim();
            OccupiedAt = DateTime.Now;
        }

        public void Release()
        {
            Status = SpotStatus.Free;
            Plate = null;
            DriverName = null;
            OccupiedAt = null;
        }
    }
}
