using System;
using System.Xml.Serialization;

namespace KP_Kursovaya_Nazarenko.Models
{
    public class ParkingEvent
    {
        public DateTime Time { get; set; }
        public string Action { get; set; }
        public string SpotCode { get; set; }
        public string Plate { get; set; }
        public string Details { get; set; }

        [XmlIgnore]
        public string TimeLabel
        {
            get { return Time.ToString("HH:mm"); }
        }
    }
}
