using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KP_Kursovaya_Nazarenko
{
    internal static class Theme
    {
        public static readonly Color Background = Color.FromArgb(244, 246, 248);
        public static readonly Color Surface = Color.White;
        public static readonly Color Header = Color.FromArgb(15, 23, 42);
        public static readonly Color HeaderMuted = Color.FromArgb(148, 163, 184);
        public static readonly Color Text = Color.FromArgb(15, 23, 42);
        public static readonly Color Muted = Color.FromArgb(100, 116, 139);
        public static readonly Color Line = Color.FromArgb(226, 232, 240);
        public static readonly Color Accent = Color.FromArgb(13, 148, 136);
        public static readonly Color AccentSoft = Color.FromArgb(204, 251, 241);
        public static readonly Color Free = Color.FromArgb(22, 163, 74);
        public static readonly Color FreeSoft = Color.FromArgb(220, 252, 231);
        public static readonly Color Occupied = Color.FromArgb(225, 29, 72);
        public static readonly Color OccupiedSoft = Color.FromArgb(255, 228, 230);
        public static readonly Color Disabled = Color.FromArgb(37, 99, 235);
        public static readonly Color DisabledSoft = Color.FromArgb(219, 234, 254);

        public static readonly Font Title = new Font("Segoe UI Semibold", 16f);
        public static readonly Font Heading = new Font("Segoe UI Semibold", 11f);
        public static readonly Font Body = new Font("Segoe UI", 9.5f);
        public static readonly Font Small = new Font("Segoe UI", 8.5f);
        public static readonly Font Mono = new Font("Consolas", 9f);

        public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void DrawRoundedFill(Graphics g, Rectangle bounds, int radius, Color color)
        {
            using (var path = RoundedRect(bounds, radius))
            using (var brush = new SolidBrush(color))
            {
                g.FillPath(brush, path);
            }
        }

        public static void DrawRoundedBorder(Graphics g, Rectangle bounds, int radius, Color color, float width = 1f)
        {
            using (var path = RoundedRect(bounds, radius))
            using (var pen = new Pen(color, width))
            {
                g.DrawPath(pen, path);
            }
        }

        public static Button CreateButton(string text, Color back, Color fore, int width = 120, int height = 34)
        {
            var button = new Button
            {
                Text = text,
                Width = width,
                Height = height,
                FlatStyle = FlatStyle.Flat,
                BackColor = back,
                ForeColor = fore,
                Font = Body,
                Cursor = Cursors.Hand,
                TabStop = true
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(back, 0.08f);
            button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(back, 0.04f);
            return button;
        }
    }
}
