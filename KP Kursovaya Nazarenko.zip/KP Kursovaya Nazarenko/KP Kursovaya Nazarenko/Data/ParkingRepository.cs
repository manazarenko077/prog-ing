using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using KP_Kursovaya_Nazarenko.Models;

namespace KP_Kursovaya_Nazarenko.Data
{
    public class ParkingRepository
    {
        private readonly string _filePath;

        public ParkingRepository()
        {
            _filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "parking-data.xml");
        }

        public ParkingLot Load()
        {
            if (!File.Exists(_filePath))
                return ParkingLot.CreateDemo();

            try
            {
                var serializer = new XmlSerializer(typeof(ParkingLot));
                using (var stream = File.OpenRead(_filePath))
                {
                    var lot = serializer.Deserialize(stream) as ParkingLot;
                    if (lot == null || lot.Spots == null || lot.Spots.Count == 0)
                        return ParkingLot.CreateDemo();
                    if (lot.Events == null)
                        lot.Events = new System.Collections.Generic.List<ParkingEvent>();
                    return lot;
                }
            }
            catch
            {
                return ParkingLot.CreateDemo();
            }
        }

        public void Save(ParkingLot lot)
        {
            var serializer = new XmlSerializer(typeof(ParkingLot));
            var settings = new XmlWriterSettings
            {
                Indent = true,
                Encoding = new UTF8Encoding(false)
            };

            using (var writer = XmlWriter.Create(_filePath, settings))
            {
                serializer.Serialize(writer, lot);
            }
        }
    }
}
