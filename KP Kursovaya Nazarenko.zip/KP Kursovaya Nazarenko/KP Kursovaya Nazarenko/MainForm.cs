using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using KP_Kursovaya_Nazarenko.Controls;
using KP_Kursovaya_Nazarenko.Data;
using KP_Kursovaya_Nazarenko.Models;

namespace KP_Kursovaya_Nazarenko
{
    public partial class MainForm : Form
    {
        private readonly ParkingRepository _repository = new ParkingRepository();
        private ParkingLot _lot;
        private ParkingMapControl _map;
        private StatCard _freeCard;
        private StatCard _busyCard;
        private StatCard _loadCard;
        private ComboBox _filterBox;
        private TextBox _searchBox;
        private TextBox _plateBox;
        private TextBox _driverBox;
        private Label _spotTitle;
        private Label _spotMeta;
        private Label _headerSubtitle;
        private ListBox _logBox;
        private Panel _occupancyFill;
        private Label _selectedHint;
        private Timer _clockTimer;

        public MainForm()
        {
            InitializeComponent();
            _lot = _repository.Load();
            BuildUi();
            StartClock();
            RefreshAll();
        }

        private void StartClock()
        {
            _clockTimer = new Timer { Interval = 1000 };
            if (components != null)
                components.Add(_clockTimer);
            _clockTimer.Tick += (s, e) => UpdateOccupiedTime();
            _clockTimer.Start();
        }

        private void BuildUi()
        {
            var header = BuildHeader();
            var sidebar = BuildSidebar();
            var workspace = BuildWorkspace();

            Controls.Add(workspace);
            Controls.Add(sidebar);
            Controls.Add(header);
        }

        private Panel BuildHeader()
        {
            var header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 78,
                BackColor = Theme.Header,
                Padding = new Padding(24, 14, 24, 14)
            };

            var title = new Label
            {
                AutoSize = true,
                Text = "Учёт парковочных мест",
                Font = Theme.Title,
                ForeColor = Color.White,
                Location = new Point(24, 12)
            };

            _headerSubtitle = new Label
            {
                AutoSize = true,
                Text = _lot.Name,
                Font = Theme.Small,
                ForeColor = Theme.HeaderMuted,
                Location = new Point(26, 44)
            };

            var occupancyTrack = new Panel
            {
                Width = 220,
                Height = 8,
                BackColor = Color.FromArgb(51, 65, 85),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            occupancyTrack.Location = new Point(Width - occupancyTrack.Width - 40, 36);

            _occupancyFill = new Panel
            {
                Height = 8,
                Width = 0,
                BackColor = Theme.Accent,
                Dock = DockStyle.Left
            };
            occupancyTrack.Controls.Add(_occupancyFill);

            header.Controls.Add(title);
            header.Controls.Add(_headerSubtitle);
            header.Controls.Add(occupancyTrack);
            header.Resize += (s, e) =>
            {
                occupancyTrack.Location = new Point(header.Width - occupancyTrack.Width - 28, 36);
            };

            return header;
        }

        private Panel BuildSidebar()
        {
            var sidebar = new Panel
            {
                Dock = DockStyle.Right,
                Width = 320,
                BackColor = Theme.Background,
                Padding = new Padding(16, 16, 20, 16)
            };

            var layout = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };

            _freeCard = new StatCard("Свободно", Theme.Free) { Width = 276 };
            _busyCard = new StatCard("Занято", Theme.Occupied) { Width = 276 };
            _loadCard = new StatCard("Загрузка", Theme.Accent) { Width = 276 };

            var detailsTitle = SectionLabel("Выбранное место");
            var detailsCard = CreateSurface(276, 248);

            _spotTitle = new Label
            {
                Text = "Не выбрано",
                Font = Theme.Heading,
                ForeColor = Theme.Text,
                Location = new Point(16, 14),
                AutoSize = true
            };
            _spotMeta = new Label
            {
                Text = "Нажмите на место на схеме",
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Location = new Point(16, 40),
                Size = new Size(240, 40)
            };

            var plateLabel = FieldLabel("Госномер", 80);
            _plateBox = CreateTextBox();
            _plateBox.Location = new Point(16, 102);
            _plateBox.Width = 244;
            _plateBox.CharacterCasing = CharacterCasing.Upper;

            var driverLabel = FieldLabel("Водитель (необязательно)", 132);
            _driverBox = CreateTextBox();
            _driverBox.Location = new Point(16, 154);
            _driverBox.Width = 244;

            var occupy = Theme.CreateButton("Занять", Theme.Accent, Color.White, 118, 34);
            occupy.Location = new Point(16, 198);
            occupy.Click += OccupyClicked;

            var release = Theme.CreateButton("Освободить", Theme.Occupied, Color.White, 118, 34);
            release.Location = new Point(142, 198);
            release.Click += ReleaseClicked;

            detailsCard.Controls.AddRange(new Control[]
            {
                _spotTitle, _spotMeta, plateLabel, _plateBox, driverLabel, _driverBox, occupy, release
            });

            var logTitle = SectionLabel("Журнал");
            var logCard = CreateSurface(276, 210);
            _logBox = new ListBox
            {
                BorderStyle = BorderStyle.None,
                Font = Theme.Small,
                Location = new Point(8, 8),
                Size = new Size(260, 194),
                IntegralHeight = false
            };
            logCard.Controls.Add(_logBox);

            layout.Controls.Add(_freeCard);
            layout.SetFlowBreak(_freeCard, true);
            layout.Controls.Add(Spacer(8));
            layout.Controls.Add(_busyCard);
            layout.SetFlowBreak(_busyCard, true);
            layout.Controls.Add(Spacer(8));
            layout.Controls.Add(_loadCard);
            layout.SetFlowBreak(_loadCard, true);
            layout.Controls.Add(Spacer(14));
            layout.Controls.Add(detailsTitle);
            layout.SetFlowBreak(detailsTitle, true);
            layout.Controls.Add(detailsCard);
            layout.SetFlowBreak(detailsCard, true);
            layout.Controls.Add(Spacer(14));
            layout.Controls.Add(logTitle);
            layout.SetFlowBreak(logTitle, true);
            layout.Controls.Add(logCard);

            sidebar.Controls.Add(layout);
            return sidebar;
        }

        private Panel BuildWorkspace()
        {
            var workspace = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Background,
                Padding = new Padding(20, 16, 8, 16)
            };

            var toolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 52,
                BackColor = Theme.Background
            };

            var filterLabel = new Label
            {
                Text = "Фильтр",
                AutoSize = true,
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Location = new Point(4, 4)
            };

            _filterBox = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = Theme.Body,
                Location = new Point(4, 22),
                Width = 160,
                FlatStyle = FlatStyle.Flat
            };
            _filterBox.Items.AddRange(new object[] { "Все", "Свободные", "Занятые", "Для инвалидов" });
            _filterBox.SelectedIndex = 0;
            _filterBox.SelectedIndexChanged += (s, e) => RefreshMap();

            var searchLabel = new Label
            {
                Text = "Поиск по номеру или месту",
                AutoSize = true,
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Location = new Point(180, 4)
            };
            _searchBox = CreateTextBox();
            _searchBox.Location = new Point(180, 20);
            _searchBox.Width = 220;
            _searchBox.TextChanged += (s, e) => RefreshMap();

            var findFree = Theme.CreateButton("Найти свободное", Theme.Header, Color.White, 150, 32);
            findFree.Location = new Point(416, 18);
            findFree.Click += FindFreeClicked;

            var reset = Theme.CreateButton("Сбросить стоянку", Color.FromArgb(241, 245, 249), Theme.Text, 150, 32);
            reset.Location = new Point(576, 18);
            reset.Click += ResetClicked;

            toolbar.Controls.AddRange(new Control[]
            {
                filterLabel, _filterBox, searchLabel, _searchBox, findFree, reset
            });

            var mapHost = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Surface,
                Padding = new Padding(8),
                AutoScroll = true
            };
            mapHost.Paint += (s, e) =>
            {
                Theme.DrawRoundedBorder(e.Graphics, new Rectangle(0, 0, mapHost.Width - 1, mapHost.Height - 1), 12, Theme.Line);
            };

            _map = new ParkingMapControl { Dock = DockStyle.Top, Height = 620 };
            _map.SelectionChanged += MapSelectionChanged;
            mapHost.Controls.Add(_map);

            _selectedHint = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Text = "Подсказка: кликните по месту, введите госномер и нажмите «Занять»."
            };

            workspace.Controls.Add(mapHost);
            workspace.Controls.Add(_selectedHint);
            workspace.Controls.Add(toolbar);
            return workspace;
        }

        private void MapSelectionChanged(object sender, EventArgs e)
        {
            ShowSelected();
        }

        private void OccupyClicked(object sender, EventArgs e)
        {
            var spot = _map.SelectedSpot;
            string error;
            if (!_lot.Occupy(spot, _plateBox.Text, _driverBox.Text, out error))
            {
                MessageBox.Show(this, error, "Нельзя занять место", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            PersistAndRefresh(spot.Code);
        }

        private void ReleaseClicked(object sender, EventArgs e)
        {
            var spot = _map.SelectedSpot;
            if (spot == null || spot.IsFree)
            {
                MessageBox.Show(this, "Выберите занятое место.", "Освобождение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var confirm = MessageBox.Show(
                this,
                "Освободить место " + spot.Code + " (" + spot.Plate + ")?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            string error;
            if (!_lot.Release(spot, out error))
            {
                MessageBox.Show(this, error, "Нельзя освободить место", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _plateBox.Clear();
            _driverBox.Clear();
            PersistAndRefresh(spot.Code);
        }

        private void FindFreeClicked(object sender, EventArgs e)
        {
            SpotType? type = null;
            if (Equals(_filterBox.SelectedItem, "Для инвалидов"))
                type = SpotType.Disabled;

            var free = _lot.FindFirstFree(type);
            if (free == null)
            {
                MessageBox.Show(this, "Свободных мест нет.", "Поиск", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _map.SelectSpot(free.Code);
            ShowSelected();
            _plateBox.Focus();
        }

        private void ResetClicked(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                this,
                "Создать новую демонстрационную стоянку? Текущие данные будут заменены.",
                "Сброс",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            _lot = ParkingLot.CreateDemo();
            PersistAndRefresh(null);
        }

        private void PersistAndRefresh(string selectedCode)
        {
            _repository.Save(_lot);
            RefreshAll(selectedCode);
        }

        private void RefreshAll(string selectedCode = null)
        {
            _headerSubtitle.Text = string.Format(
                CultureInfo.GetCultureInfo("ru-RU"),
                "{0}  ·  всего {1} мест  ·  свободно {2}",
                _lot.Name, _lot.TotalCount, _lot.FreeCount);

            _freeCard.SetValue(_lot.FreeCount.ToString());
            _busyCard.SetValue(_lot.OccupiedCount.ToString());
            _loadCard.SetValue(_lot.OccupancyPercent + "%");

            var track = _occupancyFill.Parent;
            if (track != null)
                _occupancyFill.Width = (int)(track.Width * (_lot.OccupancyPercent / 100.0));

            _logBox.Items.Clear();
            foreach (var item in _lot.Events.Take(24))
            {
                var plate = string.IsNullOrEmpty(item.Plate) ? "" : " · " + item.Plate;
                var spot = string.IsNullOrEmpty(item.SpotCode) ? "" : " " + item.SpotCode;
                _logBox.Items.Add(item.TimeLabel + "  " + item.Action + spot + plate);
            }

            RefreshMap(selectedCode);
            ShowSelected();
            UpdateOccupiedTime();
        }

        private void RefreshMap(string selectedCode = null)
        {
            var selected = selectedCode ?? (_map.SelectedSpot == null ? null : _map.SelectedSpot.Code);
            _map.Bind(_lot, Convert.ToString(_filterBox.SelectedItem), _searchBox.Text, selected);
        }

        private void ShowSelected()
        {
            var spot = _map.SelectedSpot;
            if (spot == null)
            {
                _spotTitle.Text = "Не выбрано";
                _spotMeta.Text = "Нажмите на место на схеме";
                return;
            }

            _spotTitle.Text = "Место " + spot.Code;
            if (spot.IsFree)
            {
                _spotMeta.Text = spot.TypeLabel + " · свободно";
                _plateBox.Clear();
                _driverBox.Clear();
            }
            else
            {
                _plateBox.Text = spot.Plate;
                _driverBox.Text = spot.DriverName;
                UpdateOccupiedTime();
            }
        }

        private void UpdateOccupiedTime()
        {
            var spot = _map == null ? null : _map.SelectedSpot;
            if (spot == null || spot.IsFree)
                return;

            var duration = FormatDuration(spot.OccupiedDuration);
            _spotMeta.Text = spot.TypeLabel + " · " + spot.Plate + Environment.NewLine +
                             (string.IsNullOrEmpty(spot.DriverName) ? duration : spot.DriverName + " · " + duration);
        }

        private static string FormatDuration(TimeSpan? duration)
        {
            var span = duration.GetValueOrDefault();
            if (span < TimeSpan.Zero)
                span = TimeSpan.Zero;

            if (span.TotalDays >= 1)
            {
                return string.Format(
                    CultureInfo.GetCultureInfo("ru-RU"),
                    "{0} дн {1:D2}:{2:D2}:{3:D2} на парковке",
                    (int)span.TotalDays, span.Hours, span.Minutes, span.Seconds);
            }

            return string.Format(
                CultureInfo.GetCultureInfo("ru-RU"),
                "{0:D2}:{1:D2}:{2:D2} на парковке",
                (int)span.TotalHours, span.Minutes, span.Seconds);
        }

        private static Label SectionLabel(string text)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                Font = Theme.Heading,
                ForeColor = Theme.Text,
                Margin = new Padding(0, 0, 0, 8)
            };
        }

        private static Label FieldLabel(string text, int top)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                Font = Theme.Small,
                ForeColor = Theme.Muted,
                Location = new Point(16, top)
            };
        }

        private static TextBox CreateTextBox()
        {
            return new TextBox
            {
                Font = Theme.Body,
                BorderStyle = BorderStyle.FixedSingle,
                Height = 26
            };
        }

        private static Panel CreateSurface(int width, int height)
        {
            var panel = new Panel
            {
                Width = width,
                Height = height,
                BackColor = Theme.Surface,
                Margin = new Padding(0, 0, 0, 0)
            };
            panel.Paint += (s, e) =>
            {
                Theme.DrawRoundedBorder(e.Graphics, new Rectangle(0, 0, panel.Width - 1, panel.Height - 1), 10, Theme.Line);
            };
            return panel;
        }

        private static Control Spacer(int height)
        {
            return new Panel { Width = 1, Height = height, Margin = new Padding(0) };
        }
    }
}
